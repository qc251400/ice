package com.test.demo;

public class Prog46{
    public static void main(String[] args){
        String str1 = "lao lee";
      String str2 = "牛刀";
      String str = str1+str2;
      System.out.println(str);
    }
}