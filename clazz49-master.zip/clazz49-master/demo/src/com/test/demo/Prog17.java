package com.test.demo;

public class Prog17{
    public static void main(String[] args){
        int m = 1;
      for(int i=10;i>0;i--)
        m = 2*m + 2;
      System.out.println("小猴子共摘了"+m+"桃子");
    }
}